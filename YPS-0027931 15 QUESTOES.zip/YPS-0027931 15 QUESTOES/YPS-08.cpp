#include <stdio.h>
int main() {
    int idades[5] = {15, 16, 17, 14, 15};
    for (int i = 0; i < 5; i++) {
        idades[i]++;
        printf("Nova idade no indice %d: %d\n", i, idades[i]);
    }
    return 0;
}
