#include <stdio.h>
int main() {
    float notas[4] = {7.5, 8.0, 6.5, 9.0};
    float media = 0.0;
    for (int i = 0; i < 4; i++) {
        media += notas[i];
    }
    media /= 4;
    printf("Media final do aluno: %.2f\n", media);
    return 0;
}
