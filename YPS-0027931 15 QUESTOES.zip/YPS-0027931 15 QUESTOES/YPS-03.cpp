#include <stdio.h>
int main() {
    int numeros[5] = {2, 4, 6, 8, 10};
    int soma = 0;
    for (int i = 0; i < 5; i++) {
        soma += numeros[i];
    }
    printf("Soma total: %d\n", soma);
    return 0;
}
