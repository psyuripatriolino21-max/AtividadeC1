#include <stdio.h>
int main() {
    int estoque[4] = {5, 8, 12, 3};
    for (int i = 0; i < 4; i++) {
        estoque[i]--;
        printf("Novo estoque do produto %d: %d\n", i, estoque[i]);
    }
    return 0;
}
