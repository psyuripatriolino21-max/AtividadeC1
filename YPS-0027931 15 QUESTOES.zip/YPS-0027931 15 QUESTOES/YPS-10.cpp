#include <stdio.h>
int main() {
    int salarios[4] = {1200, 1500, 2000, 2500};
    for (int i = 0; i < 4; i++) {
        salarios[i] += 150;
        printf("Salario com bonus: %d\n", salarios[i]);
    }
    return 0;
}
