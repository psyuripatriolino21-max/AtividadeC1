#include <stdio.h>
int main() {
    int vetor[5] = {5, 12, 8, 20, 15};
    int contador = 0;
    for (int i = 0; i < 5; i++) {
        if (vetor[i] > 10) {
            contador++;
        }
    }
    printf("Quantidade de numeros maiores que 10: %d\n", contador);
    return 0;
}
