#include <stdio.h>
int main() {
    int dados[6] = {11, 12, 13, 14, 15, 16};
    for (int i = 0; i < 6; i++) {
        if (dados[i] % 2 == 0) {
            printf("Par encontrado: %d\n", dados[i]);
        }
    }
    return 0;
}
