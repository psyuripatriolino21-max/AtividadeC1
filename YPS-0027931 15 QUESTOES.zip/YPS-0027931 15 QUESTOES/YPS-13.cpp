#include <stdio.h>
int main() {
    int valores[6] = {10, 10, 10, 10, 10, 10};
    for (int i = 0; i < 6; i++) {
        if (i % 2 == 0) {
            valores[i] *= 2;
        }
        printf("Posicao %d: %d\n", i, valores[i]);
    }
    return 0;
}
