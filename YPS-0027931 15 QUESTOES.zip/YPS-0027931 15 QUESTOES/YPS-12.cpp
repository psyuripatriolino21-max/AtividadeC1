#include <stdio.h>
int main() {
    int dados[5] = {-5, 10, -2, 8, -1};
    for (int i = 0; i < 5; i++) {
        if (dados[i] < 0) {
            dados[i] = 0;
        }
        printf("Elemento ajustado: %d\n", dados[i]);
    }
    return 0;
}
