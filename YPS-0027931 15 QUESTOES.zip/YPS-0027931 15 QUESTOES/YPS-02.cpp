#include <stdio.h>
int main() {
    int valores[4] = {10, 20, 30, 40};
    for (int i = 3; i >= 0; i--) {
        printf("Valor: %d\n", valores[i]);
    }
    return 0;
}
