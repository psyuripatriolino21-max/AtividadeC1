#include <stdio.h>
int main() {
    int fatores[4] = {1, 2, 3, 4};
    int resultado = 1;
    for (int i = 0; i < 4; i++) {
        resultado *= fatores[i];
    }
    printf("Resultado da multiplicacao: %d\n", resultado);
    return 0;
}
