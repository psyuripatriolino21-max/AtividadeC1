#include <stdio.h>
int main() {
    float valor_inicial = 1000.0;
    int divisores[3] = {2, 5, 2};
    for (int i = 0; i < 3; i++) {
        valor_inicial /= divisores[i];
    }
    printf("Valor final apos divisoes: %.2f\n", valor_inicial);
    return 0;
}
