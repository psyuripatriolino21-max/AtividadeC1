#include <stdio.h>
int main() {
    int total = 100;
    int despesas[3] = {15, 25, 10};
    for (int i = 0; i < 3; i++) {
        total -= despesas[i];
    }
    printf("Total restante: %d\n", total);
    return 0;
}
