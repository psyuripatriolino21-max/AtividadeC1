/*
Nome: Yuri Patriolino 
RA: 0027931

YPS-14: /*
Tipo de Tri�ngulo

Uma f�brica de estruturas met�licas produz suportes em formato de tri�ngulo para eventos e constru��es.

Antes da fabrica��o, o sistema precisa verificar o tipo do tri�ngulo com base nas medidas informadas pelo operador.

O programa deve receber os tr�s lados do tri�ngulo e informar se ele �:

Equil�tero -> todos os lados iguais;
Is�sceles -> dois lados iguais;
Escaleno -> todos os lados diferentes.
*/

#include <stdio.h>

int main() {
    float a, b, c;

    printf("Digite os tres lados: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a == b && b == c)
        printf("Equilatero");
    else if (a == b || a == c || b == c)
        printf("Isosceles");
    else
        printf("Escaleno");

    return 0;
}
